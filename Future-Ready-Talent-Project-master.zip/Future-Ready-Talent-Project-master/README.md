# Future-Ready-Talent-Project By Kabir Mittal
I acknowledge on our website that people look for a place to call their own all over the world. Because I know that buying a home involves much more than just an online search, we aim to make this process as enjoyable as discovering the ideal residence. On our website, I assist you in both finding and searching. I aid in your joy-seeking.
My website link: https://green-meadow-03699f610.1.azurestaticapps.net

there is no option to change project synopsis that why I write the whole  new Project Synopsis in my github readme file pls check it from there 

a. Detailed description and explanation with sufficient screenshots in github readme

Project Synopsis

Industry*: Lifestyle

Project Title*: Real Estate Website

Problem Statement/Opportunity*:
On our website, I create a real estate web store that helps people to find affordable rates and good-quality homes to help the people to fulfill their desired homes. On our website, I understand that people everywhere search for a home to call their own. I want to make this search as joyful as finally finding the perfect home because I know that finding a home is much more than an online search!

Project Description*:
Brick is a Real Estate website that people can use to find their dream homes. They can Find The Perfect Home. We acknowledge on our website that people look for a place to call their own all over the world. Because we know that buying a home involves much more than just an online search, we aim to make this process as enjoyable as discovering the ideal residence. I use static web apps service in my website. On our website, we assist you in both finding and searching. We aid in your joy-seeking. One would choose a brick real estate website because we offer services like Commercial, Security, Garage, and Management. Renting and Selling Services, Property Management, Relaxing Apartment, Modern Family Home, Family House Montana, Renting and Selling Services Our Agents are Lily will, Rose Hunt, Jill Kent, and Mart kelly, that help people to choose their best homes. We have Our Gallery section where people can see some beautiful homes as demos. We also mention a price table so people can use the best home according to their budget. We also show our clients' reviews on our website to satisfy them. no one can provide the quality, assurance, and trust that bricks offer you; that's why we are here to help people so that they can buy their dream home comfortably so you can contact us Get In Touch Delhi,India. info@example1.com 9899262475 9899242575

b. Azure service that I used. 

Primary Azure Technology*:
Static Web Apps, Static Web Apps.

c) The Project URL also added in Github readme.

Project Link (GitHub repository URL): https://github.com/Mittalkabir/Future-Ready-Talent-Project.git

Project Demo URL: https://green-meadow-03699f610.1.azurestaticapps.net

<img width="936" alt="1" src="https://user-images.githubusercontent.com/72194186/178821058-7c66bafc-4167-4c3f-abcd-db6181cc3f80.png">
<img width="774" alt="2" src="https://user-images.githubusercontent.com/72194186/178821103-e34986b3-1900-42ee-8018-83c0646aba9d.png">
<img width="802" alt="3" src="https://user-images.githubusercontent.com/72194186/178821130-a376aead-9225-4802-b00a-d424d6a50b00.png">
<img width="792" alt="4" src="https://user-images.githubusercontent.com/72194186/178821140-fd72371d-3635-45bc-9145-e10c8c89915d.png">
<img width="929" alt="5" src="https://user-images.githubusercontent.com/72194186/178821152-6a94ddae-1a0d-4f19-8b24-50f32a6fdd3a.png">
<img width="712" alt="6" src="https://user-images.githubusercontent.com/72194186/178821198-baa1834a-12a7-4515-ab55-26464f427183.png">
<img width="950" alt="7" src="https://user-images.githubusercontent.com/72194186/178821204-268f5e73-e55c-4f35-8bdf-f77eefa337a0.png">
<img width="672" alt="8" src="https://user-images.githubusercontent.com/72194186/178821222-c3a701d3-915b-4ebd-90aa-dcd2ace0bfe1.png">
<img width="687" alt="10" src="https://user-images.githubusercontent.com/72194186/178821229-653c52b6-1a87-44d4-9456-122123f47239.png">

d. Video URL demonstrating project demo, Azure service used and deployment of code on any Azure service in Github readme is preferred.

   video link- https://drive.google.com/file/d/18R_me3vEeBM2CDtspvc-p3seJI3L-R86/view?usp=drivesdk

